## Grunt

The `plugins.min.js` file along with its source map is generated using [Grunt](https://gruntjs.com/getting-started) (see `package.json` & `Gruntfile.js` files at the root of this project).


## Copyright

See each JS file or plugin subfolder for their respective copyright.
